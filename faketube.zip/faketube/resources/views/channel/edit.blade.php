@extends('channel.base')

@section('title', 'Edit channel')

@section('body')
    <form action="{{ route('channel.update', $channel->channel_ID) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" class="form-control" name="name" id="name" aria-describedby="helpId"
                value="{{ $channel->name }}">
        </div>
        <div class="mb-3">
            <label for="Description" class="form-label">Description</label>
            <input type="text" class="form-control" name="Description" id="Description"
                aria-describedby="helpId" value="{{ $channel->Description }}">
        </div>
        <div class="mb-3">
            <label for="sbuscribeCount" class="form-label">Sowing Season</label>
            <input type="text" class="form-control" name="sbuscribeCount" id="sbuscribeCount" aria-describedby="helpId"
                value="{{ $channel->sbuscribeCount }}">
        </div>
        <div class="mb-3">
            <label for="URL" class="form-label">Harvest Season</label>
            <input type="text" class="form-control" name="URL" id="URL" aria-describedby="helpId"
                value="{{ $channel->URL }}">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
@endsection
