@extends('channel.base')

@section('title', 'Home Page')

@section('body')
<h1 class="float-start m-4">channel Detail</h1>
<a href="{{ route('channel.create') }}"><button class="btn btn-success btn-lg float-end m-4">Add channel</button></a>
<table class="table table-striped table-bordered">
    <tr>
        <th>#</th>
        <th>Name</th>
        <th>description</th>
        <th>SubscribersCount</th>
        <th>URL</th>
    </tr>
    <tr>
        <td>{{ $channel->channel_ID}}</td>
        <td>{{ $channel->name }}</td>
        <td>{{ $channel->description }}</td>
        <td>{{ $channel->SubscribersCount}}</td>
        <td>{{ $channel->URL}}</td>
    </tr>
</table>
@endsection
