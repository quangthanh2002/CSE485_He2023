@extends('channel.base')

@section('title', 'Home Page')

@section('body')
<h1 class="float-start m-4">channel Details</h1>
<a href="{{ route('channel.create') }}"><button class="btn btn-success btn-lg float-end m-4">Add channel</button></a>
<table class="table table-striped table-bordered">
    <tr>
        <th>#</th>
        <th>Name</th>
        <th>Description</th>
        <th>SubscribersCount/th>
        <th>URL</th>
        <th>Action</th>
    </tr>
    <?php $i = 1; ?>
    @foreach ($channels as $channel)
    <tr>
        <td>{{ $i++ }}</td>
        <td>{{ $channel->name }}</td>
        <td>{{ $channel->description}}</td>
        <td>{{ $channel->subscribersCount}}</td>
        <td>{{ $channel->url}}</td>
        <td class="d-flex gap-2">
            <a href="{{ route('channel.show', $channel->channel_ID) }}" class="btn btn-primary"><i class="bi bi-eye"></i></a>
            <a href="{{ route('channel.edit', $channel->channel_ID) }}" class="btn btn-primary"><i class="bi bi-pencil-square"></i></a>
            <form action="{{ route('channel.destroy', $channel->channel_ID) }}" method="POST">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-primary"><i class="bi bi-trash"></i></button>
        </td>
    </tr>
    @endforeach
</table>
@endsection
