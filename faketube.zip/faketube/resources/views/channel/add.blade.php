@extends('channel.base')

@section('title', 'Add channel')

@section('body')
    <form action="{{ route('channel.store') }}" method="POST">
        @csrf
        {{-- @method('PUT') --}}
        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" class="form-control" name="name" id="name" aria-describedby="helpId"
                placeholder="Enter channel name here ...">
        </div>
        <div class="mb-3">
            <label for="category" class="form-label">Category</label>
            <input type="text" class="form-control" name="category" id="category"
                aria-describedby="helpId" placeholder="Enter Category">
        </div>
        <div class="mb-3">
            <label for="sowing_season" class="form-label">Sowing season</label>
            <input type="text" class="form-control" name="sowing_season" id="sowing_season" aria-describedby="helpId"
                placeholder="Enter Sowing season">
        </div>
        <div class="mb-3">
            <label for="harvest_season" class="form-label">Harvest Season</label>
            <input type="text" class="form-control" name="harvest_season" id="harvest_season" aria-describedby="helpId"
                placeholder="Enter Harvest Season">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
@endsection
