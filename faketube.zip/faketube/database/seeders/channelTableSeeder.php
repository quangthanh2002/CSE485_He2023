<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Faker\Factory as Faker;

class ChannelsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('id_ID'); // create bahasa indonesia
        for ($i = 0; $i < 50; $i++) {
            Channel::create([
                'ChannelID' => $faker->unique()->randomNumber($nbDigits = 8, $strict = false),
                'ChannelName' => $faker->name,
                'Description' => $faker->text,
                'SubscribersCount' => $faker->randomNumber($nbDigits = 8, $strict = false),
                'URL' => $faker->url,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ]);
        }
    }
}
