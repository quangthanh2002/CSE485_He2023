<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Channel;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $channel = Channel::orderBy('channel_ID', 'desc')->paginate(50);
        return view('channel.index', compact('channel'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('channel.add');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        channel::create($request->all());
        return redirect()->route('channel.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $channel = channel::find($id);
        return view('channel.show', compact('channel'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $channel = channel::find($id);
        // dd($channel);
        return view('channel.edit', compact('channel'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $channel = channel::find($id);
        $channel->update($request->all());
        return redirect()->route('channel.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $channel = channel::find($id);
        $channel->delete();
        return redirect()->route('channel.index');
    }
}
