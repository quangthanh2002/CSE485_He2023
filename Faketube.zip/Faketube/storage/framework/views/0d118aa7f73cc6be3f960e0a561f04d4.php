<?php $__env->startSection('title', 'Create'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="text-center my-4">Edit Channel</h1>
                <form action="<?php echo e(route('channel.update', $channel)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    
                    <div class="mb-3">
                        <label for="ChannelName" class="form-label">Name</label>
                        <input type="text" name="ChannelName" id="ChannelName" class="form-control" placeholder=""
                            value="<?php echo e($channel->ChannelName); ?>" aria-describedby="helpId">

                    </div>
                    <div class="mb-3">
                        <label for="Description" class="form-label">Description</label>
                        <textarea class="form-control" name="Description" id="Description" rows="3"><?php echo e($channel->Description); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="SubscribersCount" class="form-label">Subscribers</label>
                        <input type="text" name="SubscribersCount" id="SubscribersCount" class="form-control"
                            placeholder="" aria-describedby="helpId" value="<?php echo e($channel->SubscribersCount); ?>">

                    </div>
                    <div class="mb-3">
                        <label for="URL" class="form-label">URL</label>
                        <input type="text" name="URL" id="URL" class="form-control" placeholder=""
                            aria-describedby="helpId" value="<?php echo e($channel->URL); ?>">

                    </div>
                    <div class="d-flex justify-content-center mt-4">
                        <button type="submit" class="btn btn-primary" class="d-flex mx-auto">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bai Giang\Web\Laravel\project8\resources\views/channel/edit.blade.php ENDPATH**/ ?>