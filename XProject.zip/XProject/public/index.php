<?php
   require_once '../app/config/config.php';
    $controller = isset($_GET['controller'])?$_GET['controller']:'home';
    $action =  isset($_GET['action'])?$_GET['action']:'index';
    
    switch($controller){
        case "home": 
            require_once(APP_ROOT.'/app/controllers/HomeController.php');
            $homeController = new HomeController();
            switch($action){
                case "index":
                    $homeController->index();
                    break;
                case "add":
                    $homeController->add();
                    break;
                case "edit":
                    $id = $_GET['id'];
                    $homeController->edit($id);
                    break;
                case "remove":
                    $id = $_GET['id'];
                    $homeController->remove($id);
                    break;
                default:
                    break;
            }
            break;
        default:
            echo "<h1>Not found</h1>";
            break;
    }