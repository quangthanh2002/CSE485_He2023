<?php
class Employee{
    private $id;
    private $name;
    private $address;
    private $salary;
    public function __construct($id,$name,$address,$salary){
        $this->id = $id;
        $this->name = $name;
        $this->address = $address;
        $this->salary = $salary;
    }

    public function getID(){
        return $this->id;
    }
    public function setID($id){
        return $this->id = $id;
    }
    public function getName(){
        return $this->name;
    }
    public function setName($name){
        return $this->name = $name;
    }
    public function getAddress(){
        return $this->address;
    }
    public function setAddress($address){
        return $this->address = $address;
    }
    public function getSalary(){
        return $this->salary;
    }
    public function setSalary($salary){
        return $this->salary = $salary;
    }
}
?>