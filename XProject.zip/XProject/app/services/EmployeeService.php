<?php
    require_once APP_ROOT.'/app/models/Employee.php';
    require_once APP_ROOT.'/app/libs/DBConnection.php';
    class EmployeeService{
        public function getAllEmployees(){
            try{
                $dbConnection = new DBConnection();
                $conn = $dbConnection->getConnection();
                $sql = "select * from employees order by id desc";
                $stmt = $conn->query($sql);

                $employees= [];
                while($row = $stmt->fetch()){
                    $employee = new Employee($row['id'],$row['name'],$row['address'],$row['salary']);
                    $employees[] = $employee; 
                }
                return $employees;

            }catch(PDOException $e){
                return $employees = [];
                echo $e->getMessage();
            }
        }

        public function getEmployeeById($id){
            $dbConnection = new DBConnection();
            $conn = $dbConnection->getConnection();
            $sql = "select * from employees where id = $id";
            $stmt = $conn->query($sql);
            $row = $stmt->fetch();
            return new Employee($row['id'],$row['name'],$row['address'],$row['salary']);
        }

        public function addEmployee($newEmployee){
            $dbConnection = new DBConnection();
            $conn = $dbConnection->getConnection();
            $sql = "INSERT INTO `employees`(`name`, `address`, `salary`) VALUES ('".$newEmployee->getName()."','".$newEmployee->getAddress()."','".$newEmployee->getSalary()."')";
            return $stmt = $conn->query($sql);
        }
        public function editEmployee($newEmployee){
            $dbConnection = new DBConnection();
            $conn = $dbConnection->getConnection();
            $sql ="UPDATE `employees` SET `fullname`='".$newEmployee->getName()."',`address`='".$newEmployee->getAddress()."',`salary`='".$newEmployee->getSalary()."' WHERE id = ".$newEmployee->getId()."";
            return $stmt = $conn->query($sql);
        }
        public function removeEmployee($id){
            $dbConnection = new DBConnection();
            $conn = $dbConnection->getConnection();
            $sql = "DELETE FROM `employees` WHERE id = $id";
            return $stmt = $conn->query($sql);
        }
    }
?>