<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Home</title>
    <link href="<?= DOMAIN.'/public/css/bootstrap.min.css'?>" rel="stylesheet">
    <link rel="stylesheet" href="<?= DOMAIN.'/vendor/twbs/bootstrap-icons/font/bootstrap-icons.min.css'?>">
</head>
<body>
    <div class="container">
        <h3 class="text-center primary">Employee Management</h3>
        <a class="float-end btn btn-success" href="<?php echo DOMAIN;?>\public\index.php?controller=home&action=add">
        Add Employee</a>
        <table class="table">
        <thead>
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Adress</th>
            <th scope="col">Salary</th>
            <th scope="col">Edit</th>
            <th scope="col">Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php
                foreach($employees as $employee){
            ?>
                    <tr>
                        <th scope="row"><?= $employee->getId(); ?></th>
                        <td><?= $employee->getName(); ?></td>
                        <td><?= $employee->getAddress(); ?></td>
                        <td><?= $employee->getSalary(); ?></td>
                        <td>
                            <a class="btn btn-primary" href="<?=DOMAIN.'\public\index.php?controller=home&action=edit&id='.$employee->getId()?>">
                            <i class="bi bi-pencil-square"></i>
                        </a>
                        </td>
                        <td>
                            <a class="btn btn-danger" href="<?=DOMAIN.'\public\index.php?controller=home&action=remove&id='.$employee->getId()?>">
                            <i class="bi bi-trash"></i>
                        </a>
                        </td>
                    </tr>
            <?php
                }
            ?>
        </tbody>
        </table>
    </div>
    <script src="<?php echo DOMAIN?>/js/bootstrap.bundle.min.js"></script>
</body>
</html>