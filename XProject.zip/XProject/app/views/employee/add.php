<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Employee</title>
    <link href="<?= DOMAIN.'/public/css/bootstrap.min.css'?>" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h2 class="boder text-center">ADD EMPLOYEE</h2>
        <form action="<?php echo DOMAIN; ?>\public\index.php?controller=home&action=add" method="POST">
            <div class="mb-3">
                <label class="form-label">Name</label>
                <input type="text" class="form-control" name="name">
            </div>
            <div class="mb-3">
                <label class="form-label">Address</label>
                <input type="text" name="address">
            </div>
            <div class="mb-3">
                <label class="form-label">Salary</label>
                <input type="text" class="form-control" name="salary">
            </div>



            <button type="submit" name="submit" class="btn btn-primary">Submit</button>

        </form>
        <a href="index.php" class="btn btn-secondary mt-2">Home</a>
    </div>
    <script src="<?php echo DOMAIN?>/js/bootstrap.bundle.min.js"></script>
</body>
</html>