<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Employee</title>
    <link href="<?= DOMAIN.'/public/css/bootstrap.min.css'?>" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h2 class="boder text-center">EDIT EMPLOYEE</h2>
        <form action="<?php echo DOMAIN; ?>\public\index.php?controller=home&action=edit&id=<?= $employee->getId() ?>" method="POST">
            <div class="mb-3">
                <label class="form-label">ID</label>
                <input type="text" class="form-control" name="fullname" readonly value="<?= $employee->getId() ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Name</label>
                <input type="text" class="form-control" name="name" value="<?= $employee->getName() ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Adress</label>
                <input type="datetime-local" name="address" value="<?= $employee->getAddress() ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Salary</label>
                <input type="text" class="form-control" name="salary" value="<?= $employee->getSalary() ?>">
            </div>

            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
    <script src="<?=DOMAIN.'/public/js/bootstrap.bundle.min.js'?>"></script>
</body>
</html>