<?php
require_once(APP_ROOT . '/app/services/EmployeeService.php');
class HomeController
{
    function index()
    {
        $employeeService = new EmployeeService();
        $employees = $employeeService->getAllEmployees();
        require_once APP_ROOT . '/app/views/employee/index.php';
    }
    function add()
    {
        if (isset($_POST['submit'])) {
            $id = "";
            $name = $_POST['name'];
            $address = $_POST['address'];
            $salary = $_POST['salary'];
            $newEmployee = new Employee($id, $name, $address, $salary);
            $employeeService = new EmployeeService();
            $result = $employeeService->addEmployee($newEmployee);
            if ($result) {
                echo "<h1>Employee created successfully!</h1>";
            }
        }
        require_once APP_ROOT . '/app/views/employee/add.php';
    }
    function edit($id)
    {
        $employeeService = new EmployeeService();
        $employee = new Employee(1, "Nguyen Van A", "Nam", "1999-01-01");
        $employee = $employeeService->getEmployeeById($id);
        if (isset($_POST['submit'])) {
            $name = $_POST['name'];
            $address = $_POST['address'];
            $salary = $_POST['salary'];
            $newEmployee = new Employee($id, $name, $address, $salary);
            $result = $employeeService->editEmployee($newEmployee);
            if ($result) {
                header('Location: index.php');
            } else {
                echo "Error";
            }
        }
        require_once APP_ROOT . '/app/views/employee/edit.php';
    }
    function remove($id)
    {
        $employeeService = new EmployeeService();
        $result = $employeeService->removeEmployee($id);
        if ($result) {
            header('Location: index.php');
        }
    }
}
